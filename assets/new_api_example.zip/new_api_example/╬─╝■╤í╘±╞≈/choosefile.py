# -*- coding: utf-8 -*-

'''
Created on 2014年9月10日
@author: ざ凍結の→愛
@email: 892768447@qq.com
'''

from android import Android

droid = Android()

#--------------------------------
result = droid.chooseFile().result
print result
#会跳出一个只能选择sd卡里的文件选择器

#取消选择 则 result 为空
#选择文件 则路径为 result.get('data')
if result:
    print result.get('data')