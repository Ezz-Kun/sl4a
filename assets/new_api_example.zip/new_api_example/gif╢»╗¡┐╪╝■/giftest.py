# -*- coding: utf-8 -*-

'''
Created on 2014年9月10日
@author: ざ凍結の→愛
@email: 892768447@qq.com
'''

from android import Android
from os.path import dirname
import sys

droid = Android()

Path = dirname(sys.argv[0]) + '/head.gif'

layout = '''<LinearLayout xmlns:tools="http://schemas.android.com/tools"
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical" >

    <python.gif.GifImageView
        android:id="@+id/scan"
        android:layout_width="96dip"
        android:layout_height="96dip" />

</LinearLayout>
'''
#注意xml里移动要使用python.gif.GifImageView
droid.fullShow(layout)
print Path
droid.setGifView('scan',Path)
droid.eventWaitFor('key')
