# -*- coding: utf-8 -*-

'''
Created on 2014年9月10日
@author: ざ凍結の→愛
@email: 892768447@qq.com
'''

from android import Android

droid = Android()

#--------------------------------
layout = '''<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical" >

    <python.titanic.TitanicTextView
        android:id="@+id/hello"
        android:text="Hello"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_gravity="center"
        android:gravity="center"
        android:textColor="#212121"
        android:textSize="70sp"
        android:paddingLeft="5dp"
        android:paddingRight="5dp" />

    <python.titanic.TitanicTextView
        android:id="@+id/python"
        android:text="Python"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_gravity="center"
        android:gravity="center"
        android:textColor="#212121"
        android:textSize="70sp"
        android:paddingLeft="5dp"
        android:paddingRight="5dp" />

</LinearLayout>
'''
#--------------------------------

#要使用该特效需要注意在xml里面定义TextView
#的时候不是简单的TextView而是python.titanic.TitanicTextView

#--------------------------------
droid.fullShow(layout)

#重点
droid.setTitanicText('hello',False)#hello为id,False不使用字体

droid.setTitanicText('python',True)#python为id,True使用字体

droid.eventWaitFor('key')#等待按键事件退出界面
