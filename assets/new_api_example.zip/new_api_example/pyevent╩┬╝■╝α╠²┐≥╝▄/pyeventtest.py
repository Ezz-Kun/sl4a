# -*- coding: utf-8 -*-

'''
Created on 2014年9月10日
@author: ざ凍結の→愛
@email: 892768447@qq.com
'''

from android import Android
from pyevent import Event
#事件监听框架
from os.path import dirname
import sys

droid = Android()

#--------------------------------
Path = dirname(sys.argv[0])

layout_path = Path + '/layout.xml'

class Test(Event):

    def __init__(self):
        Event.__init__(self)
        #self.droid.fullShow(layout)#设置xml界面
        self.droid.fullShow(layout_path)#使用路径方式

        self.List = ['item '+str(i) for i in range(100)]
        self.setList('listView',self.List)#设置listview列表控件的列表

    def nameEvent(self,name,data):
        #这里是name监听事件,所有的事件都会被捕捉
        self.droid.appMsg('%s : %s'%(name,data),0,False)

    def clickEvent(self,Id,data):
        #这里是按钮点击事件
        print 'id: ',Id
        print 'data: ',data
        if Id == 'button':
            self.droid.eventPost('selfname','自定义name事件的内容',True)

    def itemClickEvent(self,Id,position):
        #这里是列表点击事件
        if Id == 'listView':#listview控件的id
            self.droid.appMsg(self.List[position],1,True)#提示点击的内容
            #获取List中的某一项

    def keyEvent(self,key):
        #这里是物理键按键事件
        print 'key: ',key
        if key == '82':
            self.droid.appMsg('菜单键',2,True)
        if key == '4':#返回键
            self.droid.appMsg('返回键',2,True)
            self.hide()
            self.stop()
            exit()

test = Test()
test.run()
