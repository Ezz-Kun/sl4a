# -*- coding: utf-8 -*-

'''
Created on 2014年9月10日
@author: ざ凍結の→愛
@email: 892768447@qq.com
'''

from android import Android
from pyevent import Event
#事件监听框架
from os.path import dirname
import sys

droid = Android()

#--------------------------------
Path = dirname(sys.argv[0])

composer_camera = '%s/icons/composer_camera.png'%Path
composer_music = '%s/icons/composer_music.png'%Path
composer_place = '%s/icons/composer_place.png'%Path
composer_sleep = '%s/icons/composer_sleep.png'%Path
composer_thought = '%s/icons/composer_thought.png'%Path
composer_with = '%s/icons/composer_with.png'%Path

layout_path = Path + '/layout.xml'

layout = '''<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="fill_parent"
    android:layout_height="fill_parent"
    android:background="#e0000000" >

    <python.menu.RayMenu
        android:id="@+id/ray_menu"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content"
        android:layout_alignParentLeft="true"
        android:layout_alignParentBottom="true"
        android:paddingRight="5dp" />

</RelativeLayout>
'''

class RayMenu(Event):

    def __init__(self):
        Event.__init__(self)
        #响应事件名称,事件data,图标资源
        self.droid.addRayMenuItem('a',None,composer_camera)
        self.droid.addRayMenuItem('b',None,composer_music)
        self.droid.addRayMenuItem('c',None,composer_place)
        self.droid.addRayMenuItem('d',None,composer_sleep)
        self.droid.addRayMenuItem('e',None,composer_thought)
        self.droid.addRayMenuItem('f',None,composer_with)
        #self.droid.fullShow(layout)#设置xml界面
        self.droid.fullShow(layout_path)#使用路径方式
        self.droid.fullShowRayMenu('ray_menu')#显示ray菜单

    def nameEvent(self,name,data):
        if name == 'a':
            self.droid.appMsg('a: '+str(data),2,True)
        elif name == 'b':
            self.droid.appMsg('b: '+str(data),2,True)
        elif name == 'c':
            self.droid.appMsg('c: '+str(data),2,True)
        elif name == 'd':
            self.droid.appMsg('d: '+str(data),2,True)
        elif name == 'e':
            self.droid.appMsg('e: '+str(data),2,True)
        elif name == 'f':
            self.droid.appMsg('f: '+str(data),2,True)

    def clickEvent(self,Id,data):
        print 'id: ',Id
        print 'data: ',data

    def keyEvent(self,key):
        print 'key: ',key
        if key == '4':#返回键
            self.hide()
            self.stop()
            exit()

ray = RayMenu()
ray.run()
