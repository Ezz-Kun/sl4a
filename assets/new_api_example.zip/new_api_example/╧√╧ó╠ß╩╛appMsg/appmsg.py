# -*- coding: utf-8 -*-

'''
Created on 2014年9月10日
@author: ざ凍結の→愛
@email: 892768447@qq.com
'''

from android import Android
from time import sleep

droid = Android()

#--------------------------------
#需要注意 该api 也许要xml界面的支持

layout = '''<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical" >

    <TextView
        android:id="@+id/hello"
        android:text="Hello"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_gravity="center"
        android:gravity="center"
        android:textColor="#212121"
        android:textSize="70sp"
        android:paddingLeft="5dp"
        android:paddingRight="5dp" />

</LinearLayout>
'''
droid.fullShow(layout)

#--------------------------------
#droid.appMsg('msg',level)
#参数说明:
#    参数一 为要提示的消息
#    参数二 为数字(提示级别)
#        0--错误提示
#        1--确认提示
#        3--一般提示
#    参数三
#        True 则清空为提示的其它appMsg
#        False 表示不清除其它appMsg直到轮到该提示

droid.appMsg('error',0,True)
sleep(2)

droid.appMsg('conform',1,True)
sleep(2)

droid.appMsg('info',2,True)
sleep(2)

#所以上面三个提示加了sleep延时
droid.appMsg('error',0,False)
droid.appMsg('conform',1,False)
droid.appMsg('info',2,False)

droid.eventWaitFor('key')
droid.fullDismiss()
