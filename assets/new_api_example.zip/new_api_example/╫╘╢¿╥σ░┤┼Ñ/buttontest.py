# -*- coding: utf-8 -*-

'''
Created on 2014年9月10日
@author: ざ凍結の→愛
@email: 892768447@qq.com
'''

from android import Android

droid = Android()

#这里是通过代码实现,所以xml根节点下面可以不使用xmlns:fancy="http://schemas.android.com/apk/res-auto"

layout = '''<LinearLayout xmlns:tools="http://schemas.android.com/tools"
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical">

    <python.button.FancyButton
        android:id="@+id/btn_like"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginBottom="10dp"
        android:padding="10dp" />

    <python.button.FancyButton
        android:id="@+id/btn_share"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginBottom="10dp"
        android:padding="10dp" />

    <python.button.FancyButton
        android:id="@+id/btn_follow"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginBottom="10dp"
        android:padding="10dp" />

    <python.button.FancyButton
        android:id="@+id/btn_repost"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginBottom="10dp"
        android:padding="10dp" />

</LinearLayout>
'''

droid.fullShow(layout)

'''
"id", String id, #控件id
"defaultColor", String defaultColor, #默认颜色
"text", String text, #文本
"textColor", String textColor, #文本颜色
"textSize", Integer textSize, #文本大小
"textFont", robotothin.ttf,robotoregular.ttf,Satisfy-Regular.ttf ,String textFont, #文本字体
"radius", Integer radius, #圆角大小
"focusColor", String focusColor, #焦点颜色
"fontIconSize", Integer fontIconSize, #字体图标大小
"fontIconResource", String fontIconResource, #字体图标资源
"iconPosition", String iconPosition, #图标位置
"borderColor", String borderColor, #边框颜色
"borderWidth", Integer borderWidth) #边框大小
'''

droid.setFancyButton('btn_like','#3b5998',
                     'Login with Facebook',None,
                     17,None,5,'#5474b8',
                     30,'\uf082','left',
                     None,None)

droid.setFancyButton('btn_share','#0072b1',
                     'Check in',None,
                     17,None,5,'#228fcb',
                     30,'\uf180','top',
                     None,None)

droid.setFancyButton('btn_follow','#a4c639',
                     'Google play install',None,
                     17,None,5,'#bfe156',
                     None,None,None,
                     None,None)

droid.setFancyButton('btn_repost','#ff8800',
                     'Google play install',None,
                     20,'robotothin.ttf',None,'#ffa43c',
                     None,None,None,
                     None,None)

droid.eventWaitFor('key')
