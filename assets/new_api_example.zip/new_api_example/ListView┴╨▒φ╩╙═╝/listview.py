# -*- coding: utf-8 -*-

'''
Created on 2014年9月10日
@author: ざ凍結の→愛
@email: 892768447@qq.com
'''

from android import Android
from pyevent import Event

droid = Android()

#--------------------------------
layout = '''<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent" >

    <python.listview.JazzyListView
        android:id="@+id/jazzy_list_view"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:layout_centerHorizontal="true"
        android:layout_centerVertical="true"
        android:visibility="visible" />

</RelativeLayout>
'''

#--------------------------------

#python.listview.JazzyListView 随机10多种滑动特效

class ListView(Event):
    def __init__(self):
        Event.__init__(self)
        self.setLayout(layout)
        self.show()
        self.List = ['item %s'%i for i in range(50)]
        self.droid.fullSetJList('jazzy_list_view',self.List)
        #参数一 id , 参数二 一个[]数组
        #注意和fullSetList不一样
    def itemClickEvent(self,Id,position):
        if Id == 'jazzy_list_view':
            self.droid.appMsg(self.List[position],2,True)
    def keyEvent(self,key):
        if key == '4':
            self.hide()
            self.stop()
            exit()

l = ListView()
l.run()
