# -*- coding: utf-8 -*-

'''
Created on 2014年9月10日
@author: ざ凍結の→愛
@email: 892768447@qq.com
'''

from android import Android

droid = Android()

#--------------------------------

#获取储存路径

#sd卡路径

result = droid.getSdPath().result
#得到一个含两个元素的数组
#内置sd卡和外置sd卡路径
print 'sd卡路径1: ',result[0]
print 'sd卡路径2: ',result[0]

#---------------------------------

#获取程序内部储存目录
#通常是/data/data/软件包名/files
print droid.getFilesDir().result

#---------------------------------

#获取系统 version sdk_int
#比如 android 2.2 对应的数字是 8
#这个主要用途是用于 部分api有sdk版本限制
print droid.getSdk().result

#---------------------------------

#获取系统 release
#比如 android2.2 得到2.2
print droid.getRelease().result

#---------------------------------
